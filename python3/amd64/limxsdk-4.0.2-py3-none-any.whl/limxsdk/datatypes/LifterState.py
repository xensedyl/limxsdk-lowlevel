"""
@brief Lifting column ("lifter") feedback data class.

Fed from the "/lifter/state" topic. Only the mobile dual-arm configuration has a
lifter; on other configurations the callback is never invoked.

The values are raw controller/motor-side quantities, NOT millimetres. Converting to
millimetres of travel is a per-machine calibration that lives in the chassis node
configuration, not in this SDK.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class LifterState(object):
    __slots__ = ['stamp', 'na', 'joint_names', 'q', 'v', 'vd', 'tau']
    stamp: int
    na: int
    joint_names: List[str]
    q: List[float]
    v: List[float]
    vd: List[float]
    tau: List[float]

    def __init__(self):
        self.stamp = 0
        self.na = 0
        self.joint_names = []
        self.q = []
        self.v = []
        self.vd = []
        self.tau = []
