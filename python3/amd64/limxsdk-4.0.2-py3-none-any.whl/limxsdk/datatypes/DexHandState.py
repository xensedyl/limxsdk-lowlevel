"""
@brief Dexterous hand feedback data class.

Fed from the "/brainco2/hand/state" topic. ``ctrl_mode`` and ``hands`` are both
length 2, indexed ``[left, right]``, matching the command layout.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List

from .DexHandCmd import DexHandFingers


class DexHandState(object):
    __slots__ = ['stamp', 'hand_type', 'ctrl_mode', 'hands']
    stamp: int
    hand_type: str
    ctrl_mode: List[int]
    hands: List[DexHandFingers]

    def __init__(self):
        self.stamp = 0
        self.hand_type = ''
        self.ctrl_mode = [0, 0]
        self.hands = [DexHandFingers(), DexHandFingers()]
