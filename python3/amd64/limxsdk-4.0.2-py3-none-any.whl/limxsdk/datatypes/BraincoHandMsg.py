from typing import List


class BraincoHandMsg(object):
    __slots__ = ['names', 'pos', 'vel', 'current', 'time']
    names: List[str]
    pos: List[float]
    vel: List[float]
    current: List[float]
    time: List[float]

    def __init__(self):
        self.names = []
        self.pos = []
        self.vel = []
        self.current = []
        self.time = []
