"""
@brief Lifting-column status in physical units, with fault flags.

Fed from the "/lifter/status" topic at roughly 20 Hz. Prefer this over ``LifterState``
for anything user-facing: ``position_mm`` / ``velocity_mm_s`` are already in the same
millimetre units as the arguments of ``publishLifterPos()`` / ``publishLifterVel()``,
whereas ``LifterState`` carries raw controller-side quantities.

The ``flags`` bitmask is the only way to observe why a lifter command had no effect:
a command sent while ``NOT_CALIBRATED`` or ``STATE_NOT_READY`` is set gets dropped by
the chassis node, and one whose speed was out of range comes back as
``SPEED_FALLBACK`` rather than being clamped.

Level flags versus event flags:
  * LEVEL flags are recomputed every frame and can be read directly as "the current
    condition".
  * EVENT flags are one-shot pulses, raised for a single published frame and then
    cleared, so an application that cares about them has to latch them itself.

Notes:
  * The wire message carries no header, so ``stamp`` is the time at which the SDK
    received the frame, not a publisher timestamp.
  * ``valid`` is False if the frame was shorter than expected, in which case only
    ``data`` has been populated.

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class LifterStatus(object):
    # Level flags: read directly as the current condition.
    WATCHDOG_LATCHED = 0x001  # Streaming input timed out; measured position latched and held.
    AT_LIMIT_LOWER = 0x002    # At the bottom of travel. Normal condition, not a fault.
    AT_LIMIT_UPPER = 0x004    # At the top of travel. Normal condition, not a fault.
    NOT_CALIBRATED = 0x040    # Column not calibrated; every lifter command is rejected.
    STATE_NOT_READY = 0x080   # No "/lifter/state" feedback yet; commands rejected to avoid blind motion.

    # Event flags: one-shot pulses, latch them yourself if you need them.
    LAG_SATURATED = 0x008     # Command-vs-measured lag hit its limit; mechanism may be stuck.
    SPEED_FALLBACK = 0x010    # Requested speed was out of range, configured default used instead.
    CMD_CLAMPED = 0x020       # Target position was clamped to the travel range.
    FRAME_IGNORED = 0x100     # A streaming frame was dropped because a higher-priority owner held the column.
    PREEMPTED = 0x200         # The running task was preempted by a higher-priority command.

    __slots__ = ['stamp', 'position_mm', 'velocity_mm_s', 'flags',
                 'owner', 'task', 'valid', 'data']
    stamp: int
    position_mm: float
    velocity_mm_s: float
    flags: int
    owner: int
    task: int
    valid: bool
    data: List[float]

    def __init__(self):
        self.stamp = 0
        self.position_mm = 0.0
        self.velocity_mm_s = 0.0
        self.flags = 0
        self.owner = 0
        self.task = 0
        self.valid = False
        self.data = []
