"""
@brief Dexterous hand command data classes.

Published on the "/brainco2/hand/cmd" topic. ``ctrl_mode`` and ``hands`` are both
length 2, indexed ``[left, right]``.

``ctrl_mode`` selects which finger vectors are honoured per hand:

    0 = stop
    1 = position + time   (fill ``pos`` and ``time``)
    2 = position + speed  (fill ``pos`` and ``vel``)
    3 = current / force   (fill ``current``)

The "hand mode" and "hand time" quantities are fields of this command, not
independent topics.

Finger vectors are zero-padded / truncated to the hand's finger count (6).

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class DexHandFingers(object):
    """Per-hand finger payload. All vectors share the same length (6)."""

    __slots__ = ['finger_names', 'pos', 'vel', 'current', 'time']
    finger_names: List[str]
    pos: List[float]
    vel: List[float]
    current: List[float]
    time: List[float]

    def __init__(self):
        self.finger_names = []
        self.pos = []
        self.vel = []
        self.current = []
        self.time = []


class DexHandCmd(object):
    __slots__ = ['stamp', 'hand_type', 'ctrl_mode', 'hands']
    stamp: int
    hand_type: str
    ctrl_mode: List[int]
    hands: List[DexHandFingers]

    def __init__(self):
        self.stamp = 0
        self.hand_type = ''
        self.ctrl_mode = [0, 0]
        self.hands = [DexHandFingers(), DexHandFingers()]
