"""
@brief Decoded view of the "TeleOperation" diagnostic.

The robot publishes two distinct pieces of information under the single
diagnostic name "TeleOperation", told apart by the frame id:

  * ``frame_id == "VRTakeOver"`` and ``level == 0`` (OK)
      ``code`` carries a VR take-over flag: ``1`` = take-over engaged,
      ``0`` = released. This is what ``takeover_active`` reflects.
  * any frame with ``level == 2`` (ERROR)
      A tele-operation fault, with the detail in ``message``. This is what
      ``healthy`` reflects.

Because the take-over flag is edge published (only sent when it changes),
``takeover_known`` stays ``False`` until the first "VRTakeOver" frame is seen.
Treat "not known" as "unknown", not as "not in tele-operation".

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""


class TeleopState(object):
    __slots__ = ['stamp', 'takeover_known', 'takeover_active', 'healthy',
                 'level', 'code', 'frame_id', 'message']
    stamp: int
    takeover_known: bool
    takeover_active: bool
    healthy: bool
    level: int
    code: int
    frame_id: str
    message: str

    def __init__(self):
        self.stamp = 0
        self.takeover_known = False
        self.takeover_active = False
        self.healthy = True
        self.level = 0
        self.code = 0
        self.frame_id = ''
        self.message = ''
