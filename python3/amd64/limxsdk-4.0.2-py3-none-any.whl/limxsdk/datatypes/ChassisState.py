"""
@brief Wheeled mobile base motion state data class.

Fed from the "/chassis_state" topic at roughly 30 Hz. The raw wire payload is a flat
float array; ``linear_velocity`` / ``angular_velocity`` / ``steering_angle`` are the
decoded copies of ``data[0..2]`` and ``data`` keeps the raw array.

Notes:
  * The wire message carries no header, so ``stamp`` is the time at which the SDK
    received the frame, not a publisher timestamp.
  * The chassis node stops publishing while the chassis link is down, so a stale
    ``stamp`` means "no fresh chassis data", not "zero velocity".

© [2025] LimX Dynamics Technology Co., Ltd. All rights reserved.
"""

from typing import List


class ChassisState(object):
    __slots__ = ['stamp', 'linear_velocity', 'angular_velocity',
                 'steering_angle', 'data']
    stamp: int
    linear_velocity: float
    angular_velocity: float
    steering_angle: float
    data: List[float]

    def __init__(self):
        self.stamp = 0
        self.linear_velocity = 0.0
        self.angular_velocity = 0.0
        self.steering_angle = 0.0
        self.data = []
