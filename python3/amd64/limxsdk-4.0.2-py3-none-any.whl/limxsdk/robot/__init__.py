import os
import sys
import glob
import platform

# Pre-load libpython matched to the running interpreter, otherwise _robot.so
# (a CPython extension) cannot resolve Python-C symbols.
#
# 目标机器（aarch64/amd64）随包发布 libpython3.8.so.1.0；当开发机使用其它 Python
# 版本时（如 Ubuntu 22.04 自带 3.10），首选解释器自己版本的同名文件，再回退到
# 仓库自带的 3.8 副本，最终都找不到时静默跳过——多数 Linux 发行版会让 _robot.so
# 通过自身的 NEEDED 直接拉起系统 libpython，因此跳过通常也能正常工作。
if platform.system() == "Linux":
    import ctypes

    current_dir = os.path.dirname(os.path.abspath(__file__))
    interp_ver = "{0}.{1}".format(sys.version_info[0], sys.version_info[1])

    candidates = []
    # 1) 当前解释器版本同名（开发机本机调试场景）
    candidates.append(os.path.join(current_dir, "libpython{0}.so.1.0".format(interp_ver)))
    # 2) 仓库随包发布的硬编码副本（目标机器场景）
    candidates.append(os.path.join(current_dir, "libpython3.8.so.1.0"))
    # 3) 通配兜底：任意 libpython3.*.so.1.0
    candidates.extend(sorted(glob.glob(os.path.join(current_dir, "libpython3.*.so.1.0"))))

    seen = set()
    for lib_path in candidates:
        if lib_path in seen:
            continue
        seen.add(lib_path)
        if not os.path.exists(lib_path):
            continue
        try:
            ctypes.CDLL(lib_path)
            break
        except OSError:
            continue

from .RobotType import *
from ._robot import *
from .Rate import *
from .Robot import *
from .Joystick import *